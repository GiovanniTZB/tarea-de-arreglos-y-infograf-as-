# Matriz de alumnos × materias: ¿filas o columnas?

Tarea sobre **vectores y matrices** (arreglos). El programa guarda calificaciones al azar en una matriz
(500 alumnos × 6 materias por defecto), busca al **alumno 321 en la materia 5** y compara **dos formas de acomodar
los mismos datos** para ver cuál es más rápida según la operación.

| Disposición | Filas | Columnas | Se accede con | Un alumno queda… |
|---|---|---|---|---|
| **A** | materias | alumnos | `A[materia][alumno]` | repartido (una nota en cada fila) |
| **B** | alumnos | materias | `B[alumno][materia]` | junto (todas sus notas en una fila) |

`B` se construye como la transpuesta de `A`, así que las dos matrices tienen exactamente los mismos datos.

## Cómo ejecutarlo

```bash
python matriz_alumnos.py            # demo 500×6 + benchmark completo (tarda algunos minutos)
python matriz_alumnos.py --rapido   # omite los tamaños de más de 1 millón de celdas
```

Solo necesita la librería estándar de Python. Si tienes NumPy instalado, también mide arreglos NumPy
(`pip install numpy`, opcional). Los resultados se guardan en `resultados.csv`.

## Qué se midió

Datos generados al azar (calificaciones de 0 a 100, semilla fija `2026`). Cada tiempo es la **mediana** de 3 a 7 repeticiones
con `time.perf_counter()`.

* Alumnos: 1 000, 10 000 y 100 000 (con 6 y con 100 materias).
* Materias: 100, 500 y 10 000 (con 1 000 alumnos).
* Operaciones: búsqueda directa (alumno 321, materia 5), promedio de un alumno, promedio de una materia,
  recorrido completo por filas y por columnas, y (con NumPy) promedio de un alumno / una materia.

> 100 000 alumnos × 10 000 materias son mil millones de celdas: solo los punteros de una lista de Python ocuparían
> unos 8 GB, así que esa combinación no se probó.

## Resultados (promedio de dos corridas, listas de Python 3.12)

| Alumnos | Materias | Búsqueda A | Búsqueda B | Prom. alumno A | Prom. alumno B | Prom. materia A | Prom. materia B |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 500 | 6 | 62 ns | 61 ns | 423 ns | 133 ns | 1.6 µs | 10.4 µs |
| 1 000 | 6 | 60 ns | 61 ns | 404 ns | 130 ns | 3.4 µs | 20.1 µs |
| 10 000 | 6 | 57 ns | 56 ns | 386 ns | 122 ns | 28.7 µs | 207 µs |
| 100 000 | 6 | 58 ns | 59 ns | 432 ns | 133 ns | 342 µs | 2.18 ms |
| 1 000 | 100 | 55 ns | 56 ns | 2.4 µs | 404 ns | 2.9 µs | 19.7 µs |
| 1 000 | 500 | 58 ns | 56 ns | 11.7 µs | 1.7 µs | 3.1 µs | 22.4 µs |
| 1 000 | 10 000 | 55 ns | 57 ns | 315 µs | 27.8 µs | 2.9 µs | 22.1 µs |
| 10 000 | 100 | 62 ns | 59 ns | 2.4 µs | 416 ns | 31.4 µs | 215 µs |
| 100 000 | 100 | 60 ns | 60 ns | 2.6 µs | 439 ns | 336 µs | 2.55 ms |

Salida completa: `salida_corrida1.txt` / `salida_corrida2.txt`, datos en `resultados.csv` y `resultados_corrida2.csv`.
Gráficas en `img/`.

## Conclusiones

1. **La búsqueda directa tarda lo mismo en A y en B** (≈ 60 ns) y no cambia con el tamaño. Acceder a `M[i][j]` es
   una operación O(1): se calcula la posición, no se recorre nada. Encontrar al alumno 321 en la materia 5 es igual de
   rápido con 500 alumnos que con 100 000.
2. **La disposición sí importa cuando se leen muchos datos.** Lo rápido es leer datos que están *en la misma fila*:
   * Promedio de **un alumno**: B fue de **3 a 11 veces más rápida** (en B todas sus notas están en una sola lista).
   * Promedio de **una materia**: A fue de **6 a 8 veces más rápida** (en A todas las notas de la materia están en una sola lista).
   * La ventaja crece con el tamaño de la dimensión que hay que "saltar": por ejemplo con 1 000 alumnos y 10 000 materias
     el promedio de un alumno tardó 315 µs en A contra 28 µs en B.
3. **Recorrer toda la matriz**: por filas dio prácticamente lo mismo en A y B; por columnas no hubo un ganador claro
   (solo con 100 000 × 100 la B fue ~1.8 veces más lenta). En Python con listas el tiempo lo domina el trabajo del intérprete, no la memoria.
4. **Con NumPy (memoria contigua) el efecto de la memoria se ve más:** el promedio de una materia con 100 000 × 100
   tardó ≈ 44 µs en A y ≈ 376 µs en B (unas 8.6 veces más). Leer una columna obliga a saltar de fila en fila
   y aprovecha peor la caché del procesador.
5. **No existe una disposición "mejor" en general:** depende de la operación que más se repita. Para consultar y sacar
   promedios **por alumno** (boletas), conviene `B[alumno][materia]`; para reportes **por materia**, conviene `A[materia][alumno]`.

## Limitaciones

* Los tiempos dependen de la computadora, de la versión de Python y de lo que esté corriendo en ese momento; se
  ejecutó dos veces y en operaciones de microsegundos hubo diferencias de hasta 2×. Las tendencias (lo que gana y lo que pierde) se repitieron.
  Vuelve a correr el programa en tu equipo: los números cambiarán, la conclusión no debería.
* Las listas de Python guardan referencias a objetos, no los números seguidos en memoria; por eso las diferencias con listas son
  más pequeñas que con NumPy.

## Contenido del repositorio

```
matriz_alumnos.py          programa principal
resultados.csv             datos de la corrida 1
resultados_corrida2.csv    datos de la corrida 2
salida_corrida1.txt        salida en pantalla de la corrida 1
salida_corrida2.txt        salida en pantalla de la corrida 2
img/                       infografía y gráficas
```

## Referencias

* Wikipedia. *Row- and column-major order*. https://en.wikipedia.org/wiki/Row-_and_column-major_order
* NumPy. *Internal organization of NumPy arrays*. https://numpy.org/doc/2.3/dev/internals.html
* Python Wiki. *TimeComplexity*. https://wiki.python.org/moin/TimeComplexity
