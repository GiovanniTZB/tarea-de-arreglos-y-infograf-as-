"""
Matriz de calificaciones: alumnos x materias
=============================================

Tarea: vectores y matrices (arreglos).

Que hace el programa
--------------------
1. Crea una matriz de calificaciones al azar (por defecto 500 alumnos y 6 materias).
2. Busca la calificacion del alumno 321 en la materia 5.
3. Compara DOS formas de guardar la misma informacion:

   Disposicion A -> materias en filas, alumnos en columnas:   A[materia][alumno]
   Disposicion B -> alumnos en filas, materias en columnas:   B[alumno][materia]

4. Mide el tiempo de varias operaciones con distintos tamanos (1000, 10000,
   100000 alumnos y 100, 500, 10000 materias) y guarda los resultados en un CSV.

Uso
---
    python matriz_alumnos.py            # demo 500 x 6 + benchmark completo
    python matriz_alumnos.py --rapido   # benchmark sin los tamanos mas grandes

Solo usa la libreria estandar. Si NumPy esta instalado, tambien mide arreglos
NumPy (que si guardan los datos contiguos en memoria).
"""

import argparse
import csv
import random
import statistics
import sys
import time

try:
    import numpy as np
except ImportError:  # NumPy es opcional
    np = None

SEMILLA = 2026
random.seed(SEMILLA)


# ----------------------------------------------------------------------------
# Construccion de las matrices
# ----------------------------------------------------------------------------
def crear_A(n_alumnos, n_materias):
    """Disposicion A: filas = materias, columnas = alumnos -> A[materia][alumno]."""
    return [[random.randint(0, 100) for _ in range(n_alumnos)]
            for _ in range(n_materias)]


def transponer(matriz):
    """Devuelve la matriz transpuesta (asi B tiene EXACTAMENTE los mismos datos que A)."""
    return [list(fila) for fila in zip(*matriz)]


# ----------------------------------------------------------------------------
# Operaciones que vamos a comparar
# (los numeros de alumno y materia empiezan en 1, los indices en 0)
# ----------------------------------------------------------------------------
def buscar_A(A, alumno, materia):
    return A[materia - 1][alumno - 1]


def buscar_B(B, alumno, materia):
    return B[alumno - 1][materia - 1]


def promedio_alumno_A(A, alumno):
    """En A las notas de un alumno estan repartidas: una por cada fila."""
    j = alumno - 1
    return sum(fila[j] for fila in A) / len(A)


def promedio_alumno_B(B, alumno):
    """En B las notas de un alumno estan juntas en una sola fila."""
    fila = B[alumno - 1]
    return sum(fila) / len(fila)


def promedio_materia_A(A, materia):
    """En A las notas de una materia estan juntas en una sola fila."""
    fila = A[materia - 1]
    return sum(fila) / len(fila)


def promedio_materia_B(B, materia):
    """En B las notas de una materia estan repartidas: una por cada fila."""
    j = materia - 1
    return sum(fila[j] for fila in B) / len(B)


def recorrer_por_filas(M):
    """Recorre toda la matriz fila por fila (orden natural de Python/C)."""
    total = 0
    for fila in M:
        for x in fila:
            total += x
    return total


def recorrer_por_columnas(M):
    """Recorre toda la matriz columna por columna (salta de fila en fila)."""
    total = 0
    filas = len(M)
    columnas = len(M[0])
    for j in range(columnas):
        for i in range(filas):
            total += M[i][j]
    return total


# ----------------------------------------------------------------------------
# Utilidades de medicion
# ----------------------------------------------------------------------------
def medir(func, *args, repeticiones=5, veces_por_rep=1):
    """Devuelve el tiempo (segundos) de UNA llamada: la mediana de varias repeticiones."""
    tiempos = []
    for _ in range(repeticiones):
        t0 = time.perf_counter()
        for _ in range(veces_por_rep):
            func(*args)
        t1 = time.perf_counter()
        tiempos.append((t1 - t0) / veces_por_rep)
    return statistics.median(tiempos)


def fmt(segundos):
    """Formatea un tiempo de forma legible."""
    if segundos < 1e-6:
        return f"{segundos * 1e9:8.1f} ns"
    if segundos < 1e-3:
        return f"{segundos * 1e6:8.1f} us"
    if segundos < 1:
        return f"{segundos * 1e3:8.2f} ms"
    return f"{segundos:8.3f} s "


# ----------------------------------------------------------------------------
# Parte 1: la demo que pide la tarea (500 alumnos, 6 materias, alumno 321, materia 5)
# ----------------------------------------------------------------------------
def demo(n_alumnos=500, n_materias=6, alumno=321, materia=5):
    print("=" * 70)
    print(f"DEMO: {n_alumnos} alumnos x {n_materias} materias")
    print("=" * 70)
    A = crear_A(n_alumnos, n_materias)   # A[materia][alumno]
    B = transponer(A)                    # B[alumno][materia]

    print(f"Tamano de A: {len(A)} filas x {len(A[0])} columnas (materias x alumnos)")
    print(f"Tamano de B: {len(B)} filas x {len(B[0])} columnas (alumnos x materias)")

    cal_A = buscar_A(A, alumno, materia)
    cal_B = buscar_B(B, alumno, materia)
    print(f"\nCalificacion del alumno {alumno} en la materia {materia}:")
    print(f"  Disposicion A -> A[{materia - 1}][{alumno - 1}] = {cal_A}")
    print(f"  Disposicion B -> B[{alumno - 1}][{materia - 1}] = {cal_B}")
    assert cal_A == cal_B, "Las dos disposiciones deben dar el mismo dato"

    t_A = medir(buscar_A, A, alumno, materia, repeticiones=7, veces_por_rep=200_000)
    t_B = medir(buscar_B, B, alumno, materia, repeticiones=7, veces_por_rep=200_000)
    print("\nTiempo de UNA busqueda directa (mediana):")
    print(f"  Disposicion A: {fmt(t_A)}")
    print(f"  Disposicion B: {fmt(t_B)}")
    print()


# ----------------------------------------------------------------------------
# Parte 2: benchmark con distintos tamanos
# ----------------------------------------------------------------------------
# (alumnos, materias). Las combinaciones muy grandes (100000 x 10000 = mil
# millones de celdas) no caben en memoria, por eso se prueban por separado
# los alumnos (con pocas materias) y las materias (con pocos alumnos).
TAMANOS = [
    (500, 6),
    (1_000, 6),
    (10_000, 6),
    (100_000, 6),
    (1_000, 100),
    (1_000, 500),
    (1_000, 10_000),
    (10_000, 100),
    (100_000, 100),
]
TAMANOS_RAPIDO = [t for t in TAMANOS if t[0] * t[1] <= 1_000_000]


def benchmark(tamanos, archivo_csv="resultados.csv"):
    filas_csv = []
    encabezado = ["alumnos", "materias", "celdas", "estructura", "operacion", "tiempo_s"]

    for n_alumnos, n_materias in tamanos:
        celdas = n_alumnos * n_materias
        print("-" * 70)
        print(f"{n_alumnos} alumnos x {n_materias} materias  ({celdas:,} celdas)")
        print("-" * 70)

        A = crear_A(n_alumnos, n_materias)
        B = transponer(A)

        # Para que el alumno 321 / materia 5 existan siempre:
        alumno = min(321, n_alumnos)
        materia = min(5, n_materias)
        # Y un alumno / materia "del final" para no favorecer al inicio
        alumno_f, materia_f = n_alumnos, n_materias

        rep = 5 if celdas <= 1_000_000 else 3

        pruebas = [
            ("busqueda directa (321, 5)",
             ("listas A", buscar_A, (A, alumno, materia), dict(veces_por_rep=100_000)),
             ("listas B", buscar_B, (B, alumno, materia), dict(veces_por_rep=100_000))),
            ("promedio de 1 alumno",
             ("listas A", promedio_alumno_A, (A, alumno_f), dict(veces_por_rep=50 if n_materias <= 500 else 3)),
             ("listas B", promedio_alumno_B, (B, alumno_f), dict(veces_por_rep=50 if n_materias <= 500 else 3))),
            ("promedio de 1 materia",
             ("listas A", promedio_materia_A, (A, materia_f), dict(veces_por_rep=20 if n_alumnos <= 10_000 else 3)),
             ("listas B", promedio_materia_B, (B, materia_f), dict(veces_por_rep=20 if n_alumnos <= 10_000 else 3))),
            ("recorrido completo por filas",
             ("listas A", recorrer_por_filas, (A,), dict(veces_por_rep=1)),
             ("listas B", recorrer_por_filas, (B,), dict(veces_por_rep=1))),
            ("recorrido completo por columnas",
             ("listas A", recorrer_por_columnas, (A,), dict(veces_por_rep=1)),
             ("listas B", recorrer_por_columnas, (B,), dict(veces_por_rep=1))),
        ]

        for nombre_op, (est1, f1, a1, k1), (est2, f2, a2, k2) in pruebas:
            t1 = medir(f1, *a1, repeticiones=rep, **k1)
            t2 = medir(f2, *a2, repeticiones=rep, **k2)
            print(f"  {nombre_op:34s} A: {fmt(t1)}   B: {fmt(t2)}")
            filas_csv.append([n_alumnos, n_materias, celdas, est1, nombre_op, t1])
            filas_csv.append([n_alumnos, n_materias, celdas, est2, nombre_op, t2])

        # ---- Extra: arreglos NumPy (memoria contigua) ----
        # Misma operacion sobre las dos disposiciones (comparacion "justa").
        if np is not None:
            NA = np.array(A, dtype=np.int32)   # (materias, alumnos), orden C
            NB = np.ascontiguousarray(NA.T)    # (alumnos, materias), orden C
            j_al, j_ma = alumno_f - 1, materia_f - 1

            ops_np = [
                ("NumPy promedio de 1 alumno",
                 lambda M: M[:, j_al].mean(), lambda M: M[j_al, :].mean()),
                ("NumPy promedio de 1 materia",
                 lambda M: M[j_ma, :].mean(), lambda M: M[:, j_ma].mean()),
            ]
            for nombre_op, fA, fB in ops_np:
                t1 = medir(fA, NA, repeticiones=rep, veces_por_rep=500)
                t2 = medir(fB, NB, repeticiones=rep, veces_por_rep=500)
                print(f"  {nombre_op:34s} A: {fmt(t1)}   B: {fmt(t2)}")
                filas_csv.append([n_alumnos, n_materias, celdas, "numpy A", nombre_op, t1])
                filas_csv.append([n_alumnos, n_materias, celdas, "numpy B", nombre_op, t2])
            del NA, NB

        del A, B

    with open(archivo_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(encabezado)
        w.writerows(filas_csv)
    print(f"\nResultados guardados en {archivo_csv}")


def main():
    parser = argparse.ArgumentParser(description="Matriz alumnos x materias")
    parser.add_argument("--rapido", action="store_true",
                        help="omite los tamanos con mas de 1 millon de celdas")
    parser.add_argument("--csv", default="resultados.csv", help="archivo de salida")
    args = parser.parse_args()

    print(f"Python {sys.version.split()[0]}"
          + (f" | NumPy {np.__version__}" if np is not None else " | (sin NumPy)"))
    demo()
    benchmark(TAMANOS_RAPIDO if args.rapido else TAMANOS, args.csv)


if __name__ == "__main__":
    main()
